function filterShirts() {
    var filter = document.getElementById("filter").value;
    var shirts = document.querySelectorAll(".shirt");

    shirts.forEach(function(shirt) {
        if (filter === "all" || shirt.getAttribute("data-year") === filter) {
            shirt.style.display = "block";
        } else {
            shirt.style.display = "none";
        }
    });
}
